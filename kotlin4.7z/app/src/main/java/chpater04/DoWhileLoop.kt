package chpater04

fun main(){
    do{
        print("Enter the an Interger")
        val input = readLine()!!.toInt()
        for(i in 0 until input){
            for(j in 0 until input){
                print((i+j)%input+1)
            }
            println()
        }
    }while (input!=0)
}
