package exchange.example.newopenapiexchangeproject3;

public class SearchNaverCallMethod {

    public void SearchNaverCallMethod(){
//        searching("아랍에미리트",0);
//        searching("호주",1);
//        searching("바레인",2);
//        searching("캐나다",3);
//        searching("스위스",4);
//        searching("위안화",5);
//        searching("덴마크",6);
//        searching("유로",7);
//        searching("영국",8);
//        searching("홍콩",9);
//        searching("인도네시아",10);
//        searching("일본",11);
//        searching("한국",12);
//        searching("쿠웨이트",13);
//        searching("말레이지아",14);
//        searching("노르웨이",15);
//        searching("뉴질랜드",16);
//        searching("사우디",17);
//        searching("스웨덴",18);
//        searching("싱가포르",19);
//        searching("태국",20);
//        searching("미국",21);
    }

}
